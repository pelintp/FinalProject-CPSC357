//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by pelin on 11/29/23.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
